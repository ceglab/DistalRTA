Clazz.load(["java.util.Collection"],"java.util.List",null,function(){
Clazz.declareInterface(java.util,"List",java.util.Collection);
});
