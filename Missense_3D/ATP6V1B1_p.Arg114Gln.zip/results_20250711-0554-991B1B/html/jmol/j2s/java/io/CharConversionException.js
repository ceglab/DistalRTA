Clazz.load(["java.io.IOException"],"java.io.CharConversionException",null,function(){
c$=Clazz.declareType(java.io,"CharConversionException",java.io.IOException);
});
