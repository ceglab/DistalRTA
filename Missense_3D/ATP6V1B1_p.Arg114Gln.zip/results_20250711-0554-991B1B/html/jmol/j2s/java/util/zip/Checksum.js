﻿Clazz.declarePackage ("java.util.zip");
Clazz.declareInterface (java.util.zip, "Checksum");
