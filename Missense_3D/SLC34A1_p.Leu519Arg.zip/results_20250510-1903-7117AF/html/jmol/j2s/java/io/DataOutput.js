Clazz.declareInterface (java.io, "DataOutput");
