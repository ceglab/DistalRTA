Clazz.load(["java.io.IOException"],"java.util.InvalidPropertiesFormatException",["java.io.NotSerializableException"],function(){
c$=Clazz.declareType(java.util,"InvalidPropertiesFormatException",java.io.IOException);
Clazz.makeConstructor(c$,
function(c){
Clazz.superConstructor(this,java.util.InvalidPropertiesFormatException,[]);
this.initCause(c);
},"Throwable");
});
