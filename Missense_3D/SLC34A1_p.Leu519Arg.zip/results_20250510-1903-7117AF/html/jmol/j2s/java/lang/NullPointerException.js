Clazz.load(["java.lang.RuntimeException"],"java.lang.NullPointerException",null,function(){
c$=Clazz.declareType(java.lang,"NullPointerException",RuntimeException);
});
