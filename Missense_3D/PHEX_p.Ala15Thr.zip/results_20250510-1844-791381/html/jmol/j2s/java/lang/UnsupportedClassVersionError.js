Clazz.load(["java.lang.ClassFormatError"],"java.lang.UnsupportedClassVersionError",null,function(){
c$=Clazz.declareType(java.lang,"UnsupportedClassVersionError",ClassFormatError);
});
