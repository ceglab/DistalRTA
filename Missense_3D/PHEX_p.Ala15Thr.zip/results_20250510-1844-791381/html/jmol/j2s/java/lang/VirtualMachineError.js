Clazz.load(["java.lang.Error"],"java.lang.VirtualMachineError",null,function(){
c$=Clazz.declareType(java.lang,"VirtualMachineError",Error);
});
