Clazz.load(["java.io.IOException"],"java.io.InterruptedIOException",null,function(){
c$=Clazz.decorateAsClass(function(){
this.bytesTransferred=0;
Clazz.instantialize(this,arguments);
},java.io,"InterruptedIOException",java.io.IOException);
});
