Clazz.load(["java.io.IOException"],"java.io.ObjectStreamException",null,function(){
c$=Clazz.declareType(java.io,"ObjectStreamException",java.io.IOException);
});
