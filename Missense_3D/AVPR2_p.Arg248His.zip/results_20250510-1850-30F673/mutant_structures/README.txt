Please note that the coordinates for the wildtype and mutant structures have
been repacked using the SCWRL4 program.  

Your wildtype structure is labelled
     PDB-[pdb code or file name]-[Chain ID].sc.pdb
Your mutant structure is labelled
     PDB-[pdb code or file name]-[Chain ID]-[Mutant residue ID and name].sc.pdb



